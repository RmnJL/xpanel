#!/bin/bash
#XPanel Alireza
rm -fr /var/log/auth.log
systemctl restart syslog